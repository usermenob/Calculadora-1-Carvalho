#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void intToBinary(int n) {
    printf("Base 2: ");
    for (int i = sizeof(n) * 8 - 1; i >= 0; i--) {
        printf("%d", (n >> i) & 1);
    }
    printf("\n");
}

void intToOctal(int n) {
    printf("Base 8: %o\n", n);
}

void intToHex(int n) {
    printf("Base 16: %X\n", n);
}

void intToBCD(int n) {
    printf("Código BCD: ");
    while (n) {
        int digit = n % 10;
        printf("%04d ", digit);
        n /= 10;
    }
    printf("\n");
}

void printFloatDetails(float num) {
    unsigned int bits = *((unsigned int*)&num);
    int sign = (bits >> 31) & 1;
    int exponent = (bits >> 23) & 0xFF;
    int fraction = bits & 0x7FFFFF;

    printf("Representação float:\n");
    printf("Sinal: %d\n", sign);
    printf("Expoente: %d\n", exponent);
    printf("Expoente com viés: %d\n", exponent - 127);
    printf("Frações: %u\n", fraction);
}

void printDoubleDetails(double num) {
    unsigned long long bits = *((unsigned long long*)&num);
    int sign = (bits >> 63) & 1;
    int exponent = (bits >> 52) & 0x7FF;
    long long fraction = bits & 0xFFFFFFFFFFFFF;

    printf("Representação double:\n");
    printf("Sinal: %d\n", sign);
    printf("Expoente: %d\n", exponent);
    printf("Expoente com viés: %lld\n", exponent - 1023);
    printf("Frações: %llu\n", fraction);
}

int main() {
    int integerInput;
    float floatInput;
    double doubleInput;

    printf("Digite um número inteiro (base 10): ");
    scanf("%d", &integerInput);

    intToBinary(integerInput);
    intToOctal(integerInput);
    intToHex(integerInput);
    intToBCD(integerInput);

    printf("\nDigite um número real (float): ");
    scanf("%f", &floatInput);
    printFloatDetails(floatInput);

    printf("\nDigite um número real (double): ");
    scanf("%lf", &doubleInput);
    printDoubleDetails(doubleInput);

    return 0;
}
